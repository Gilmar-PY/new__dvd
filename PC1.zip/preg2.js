/*  
creacion de una palicacion 
*/

/**
   * Itera sobre el array de objetos y realiza el análisis estadístico por categoría.
   * @param {DataObject[]} datos - El array de objetos de datos.
   * @returns {Object} - Un objeto con los resultados del análisis por categoría.
   */
function realizarAnalisisPorCategoria(datos) {
    const categorias = {};
  
    // Iterar y agrupar por categoría
    for (const { category, value } of datos) {
      if (!validarNumeros([value])) {
        console.error(`Valor no numérico encontrado en la categoría ${category}: ${value}`);
        continue;
      }
  
      if (!categorias[category]) {
        categorias[category] = [];
      }
      categorias[category].push(value);
    }
  
    // Calcular estadísticas por categoría
    const resultados = {};
    for (const [categoria, valores] of Object.entries(categorias)) {
      resultados[categoria] = {
        media: calcularMedia(valores),
        mediana: calcularMediana(valores),
        moda: calcularModa(valores),
        desviacionEstandar: calcularDesviacionEstandar(valores),
      };
    }
    return resultados;
  }   
  /**
   * Calcula la diferencia en días entre dos fechas.
   * @param {Date} fecha1 - rimera fecha.
   * @param {Date} fecha2 -segunda fecha.
   * @returns {number} - diferencia en días.
   */
  function calcularDiferenciaDias(fecha1, fecha2) {
    const diferenciaTiempo = Math.abs(fecha2 - fecha1);
    return Math.ceil(diferenciaTiempo / (1000 * 60 * 60 * 24));
  }
  /**
   *  se Muestra los resultados del análisis
   * @param {Object} resultados - objeto con el resultados de  estadísticas
   */
  function mostrarResultados(resultados) {
    console.log("Resultados del análisis estadístico:");
    for (const [categoria, estadisticas] of Object.entries(resultados)) {
      console.log(`Categoría: ${categoria}`);
      console.log(`  Media: ${estadisticas.media}`);
      console.log(`  Mediana: ${estadisticas.mediana}`);
      console.log(`  Moda: ${estadisticas.moda.length > 1 ? estadisticas.moda.join(", ") : estadisticas.moda[0]}`);
      console.log(`  Desviación estándar: ${estadisticas.desviacionEstandar.toFixed(2)}`);
    }
  }
  
  
   // Módulo paraanálisis estadístico dinámico
   
  async function iniciarAnalisis() {
    const { default: BigInt } = await import('bigint'); 
    // Datos random de prueba
    const datos = [
      { category: "Edad", value: 25 },
      { category: "Edad", value: 30 },
      { category: "Edad", value: 25 },
      { category: "Ingresos", value: 50000 },
      { category: "Ingresos", value: 60000 },
      { category: "Ingresos", value: 75000 },
      { category: "Fecha", value: 10, date: new Date("2023-09-01") }
    ];
  
    //  análisis estadístico
    const resultados = realizarAnalisisPorCategoria(datos);
    mostrarResultados(resultados);
   
    // diferencia de fechas
    const fecha1 = new Date("2024-01-01");
    const fecha2 = new Date("2024-09-01");
    const dias = calcularDiferenciaDias(fecha1, fecha2);
    console.log(`Diferencia entre ${fecha1.toDateString()} y ${fecha2.toDateString()}: ${dias} días`);
  
    // uso de BigInt
    const numeroGrande = BigInt(12345678901234567890n);
    console.log("usando BigInt:", numeroGrande);
  }
  
  // ejecusion
  iniciarAnalisis();
  









/*

//-------------------------
//Salida del ejercicio 2
//-------------------------
LOs Resultados del análisis:
Categoría: Edad
  Media: 26.666666666666668
  Mediana: 25
  Moda: 25
  Desviación estándar: 2.36
Categoría: Ingresos
  Media: 61666.666666666664
  Mediana: 60000
  Moda: 50000, 60000, 75000
  Desviación estándar: 10206.22
Diferencia entre Mon Jan 01 2024*/