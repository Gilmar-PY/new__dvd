/* prguntta1 
desarrollar gestion de tareas
*/

let categoriasList=[" estudiar","deporte","caminar"];
function tareas(nombre, estado){
    this.nombre =" juan";
    this.estado =" personasSolas";

       
}

function crud(agregar,eliminar, actulaizar){


    let tarea1_agregar= "realizr la actividad4";
    let tarea2_agregar=" resolver ejercicios";
    agregar= ("tarea1_agregar"+ "tarea2_agregar");
    eliminar.destructuring( tarea1_agregar,tarea2_agregar);
    actulaizar.destructuring( tarea1_agregar,tarea2_agregar)
    console.log("eliminar tarea", {agregar});
    console.log("eliminar tareas",{eliminar});
    console.log("actulaizar tareas", {actulaizar});

// aqui se muestra  la opraciones tanto de agrgara como eliminar 
}
// iteracion compleja y copias 
function categorias(arr){
    cat = [];
    let nuevoccategori = "catntar";
    rrecorrido=categoriasList(arr(nuevoccategori)); 
}
function manejo_propiedades{
    propiedadesno_definidas=chaining(categoriasList);
    return propiedadesno_definidas;
}
function Uso_ECMAS(){

}
cosnsolo.log("categorias:",{categorias});
cosnsolo.log("Crud:", {crud});
cosnsolo.log("categorias", {categorias});
cosnsolo.log("manejo de propiedades", { manejo_propiedades});

/////////////////
